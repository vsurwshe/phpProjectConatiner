<?php 

define('DB_HOST', 'php_rest_api_db');
define('DB_USER', 'vishva');
define('DB_PASSWORD', 'admin@123');
define('DB_NAME', 'employee');

?>